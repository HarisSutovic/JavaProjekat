package Zadaci111;

class Kuvar extends Zaposleni {
    Kuvar(String id, String ime, String prezime, double plataPoSatu, double brojSati) {
        super(id, ime, prezime, plataPoSatu, brojSati);
    }

    @Override
    double izracunajPlatu() {
        return 1500 + 4 * brojSati * plataPoSatu;
    }

    @Override
    String getTip() {
        return "Kuvar";
    }
}
