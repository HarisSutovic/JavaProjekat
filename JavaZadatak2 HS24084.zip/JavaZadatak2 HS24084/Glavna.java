package Zadaci111;

public class Glavna {
    public static void main(String[] args) {
        Konobar k = new Konobar("K1", "Petar", "Simonović", 6.5, 40, 10);
        Kuvar c = new Kuvar("C1", "Haris", "Sutović", 8.0, 42);
        Menadzer m = new Menadzer("M1", "Mitar", "Petrović", 10.0, 38, 200);

        Zaposleni[] lista = {k, c, m};

        double ukupno = 0;
        System.out.printf("%-5s %-10s %-10s %-10s %-10s%n", "ID", "Ime", "Prezime", "Tip", "Plata");
        for (Zaposleni z : lista) {
            double plata = z.izracunajPlatu();
            ukupno += plata;
            System.out.printf("%-5s %-10s %-10s %-10s %-10.2f%n",
                    z.id, z.ime, z.prezime, z.getTip(), plata);
        }
        System.out.println("Ukupni trošak plata: " + ukupno + " EUR");
    }
}

