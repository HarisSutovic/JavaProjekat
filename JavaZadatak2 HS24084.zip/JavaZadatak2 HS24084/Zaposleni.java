package Zadaci111;

class Zaposleni {
    String id;
    String ime;
    String prezime;
    double plataPoSatu;
    double brojSati;

    Zaposleni(String id, String ime, String prezime, double plataPoSatu, double brojSati) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.plataPoSatu = plataPoSatu;
        this.brojSati = brojSati;
    }

    double izracunajPlatu() {
        return 0;
    }

    String getTip() {
        return "Zaposleni";
    }
}

