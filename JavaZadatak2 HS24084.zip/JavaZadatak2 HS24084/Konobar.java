package Zadaci111;

class Konobar extends Zaposleni {
    double prekovremeni;

    Konobar(String id, String ime, String prezime, double plataPoSatu, double brojSati, double prekovremeni) {
        super(id, ime, prezime, plataPoSatu, brojSati);
        this.prekovremeni = prekovremeni;
    }

    @Override
    double izracunajPlatu() {
        return 4 * brojSati * plataPoSatu + prekovremeni * (plataPoSatu * 1.2);
    }

    @Override
    String getTip() {
        return "Konobar";
    }
}

