package Zadaci111;


class Menadzer extends Zaposleni {
    double bonus;

    Menadzer(String id, String ime, String prezime, double plataPoSatu, double brojSati, double bonus) {
        super(id, ime, prezime, plataPoSatu, brojSati);
        this.bonus = bonus;
    }

    @Override
    double izracunajPlatu() {
        return 1300 + 4 * brojSati * plataPoSatu + bonus;
    }

    @Override
    String getTip() {
        return "Menadžer";
    }
}

