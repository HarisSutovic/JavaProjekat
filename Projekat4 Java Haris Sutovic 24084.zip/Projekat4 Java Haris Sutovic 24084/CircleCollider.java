package Projekat;

class CircleCollider implements Collidable {
private double x;
private double y;
private double r;


public CircleCollider(double r) {
if (r <= 0) throw new IllegalArgumentException();
this.r = r;
}


public void setPosition(double x, double y) {
this.x = x;
this.y = y;
}


public boolean intersects(Collidable other) {
if (other instanceof CircleCollider) {
CircleCollider c = (CircleCollider) other;
double dx = x - c.x;
double dy = y - c.y;
return dx * dx + dy * dy <= (r + c.r) * (r + c.r);
}
if (other instanceof RectangleCollider) {
RectangleCollider rc = (RectangleCollider) other;
double cx = x;
double cy = y;
double rx = rc.x;
double ry = rc.y;
double rw = rc.w;
double rh = rc.h;
double closestX = clamp(cx, rx - rw / 2, rx + rw / 2);
double closestY = clamp(cy, ry - rh / 2, ry + rh / 2);
double dx = cx - closestX;
double dy = cy - closestY;
return dx * dx + dy * dy <= r * r;
}
return false;
}


private double clamp(double v, double min, double max) {
if (v < min) return min;
if (v > max) return max;
return v;


        }


}