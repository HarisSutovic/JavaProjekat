package Projekat;

class RectangleCollider implements Collidable {
private double x;
private double y;
private double w;
private double h;


public RectangleCollider(double w, double h) {
if (w <= 0 || h <= 0) throw new IllegalArgumentException();
this.w = w;
this.h = h;
}


public void setPosition(double x, double y) {
this.x = x;
this.y = y;
}


public boolean intersects(Collidable other) {
if (other instanceof RectangleCollider) {
RectangleCollider o = (RectangleCollider) other;
return Math.abs(x - o.x) * 2 < (w + o.w) && Math.abs(y - o.y) * 2 < (h + o.h);
}
if (other instanceof CircleCollider) {
return other.intersects(this);
}
return false;
}
}