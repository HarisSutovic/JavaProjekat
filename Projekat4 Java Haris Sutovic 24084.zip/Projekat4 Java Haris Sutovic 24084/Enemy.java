package Projekat;

class Enemy extends GameObject implements Attacker {
protected String type;
protected int damage;
protected int health;


public Enemy(String t, double x, double y, Collidable c, int dmg, int hp) {
super(x, y, c);
t = t.trim();
if (t.isEmpty()) throw new IllegalArgumentException();
type = t;
if (dmg < 0 || dmg > 100) throw new IllegalArgumentException();
if (hp < 0 || hp > 100) throw new IllegalArgumentException();
damage = dmg;
health = hp;


}


public int getEffectiveDamage() { return damage; }
public String getDisplayName() { return type; }


public String toString() {
return "Enemy(" + type + ") @ (" + x + "," + y + ") DMG=" + damage + " HP=" + health;


      }
}