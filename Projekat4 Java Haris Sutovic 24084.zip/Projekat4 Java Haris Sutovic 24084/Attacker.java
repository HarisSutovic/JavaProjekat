package Projekat;

interface Attacker { int getEffectiveDamage(); 

}