package Projekat;

class Player extends GameObject {
private String name;
private int health;


public Player(String name, double x, double y, Collidable c, int health) {
super(x, y, c);
name = name.trim().replaceAll(" +", " ");
if (name.isEmpty()) throw new IllegalArgumentException();
String[] parts = name.split(" ");
StringBuilder b = new StringBuilder();
for (String s : parts) b.append(Character.toUpperCase(s.charAt(0))).append(s.substring(1).toLowerCase()).append(" ");
this.name = b.toString().trim();
if (health < 0 || health > 100) throw new IllegalArgumentException();
this.health = health;


}


public String getDisplayName() { return name; }


public int getHealth() { return health; }
public void setHealth(int h) { health = h; }


public String toString() {
return "Player(" + name + ") @ (" + x + "," + y + ") HP=" + health;

      }

}