package Projekat;

class MeleeEnemy extends Enemy {
public MeleeEnemy(String t, double x, double y, Collidable c, int d, int h) {
super(t, x, y, c, d, h);
      
       }
}