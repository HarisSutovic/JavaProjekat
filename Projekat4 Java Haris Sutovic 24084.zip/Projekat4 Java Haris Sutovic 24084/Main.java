package Projekat;

public class Main {
public static void main(String[] args) {
Player p = new Player("petar petrovic", 10, 5, new RectangleCollider(32, 32), 100);
Game g = new Game(p);


Enemy e1 = new MeleeEnemy("Goblin", 12.5, 16, new RectangleCollider(16, 16), 20, 60);
g.addEnemy(e1);


Enemy e2 = Game.parseEnemy("Goblin;12.5;16;16x16;boss");
g.addEnemy(e2);


System.out.println("Before: " + p);
g.resolveCollisions();
System.out.println("After: " + p);


for (String log : g.getLog()) System.out.println(log);
      
       }
}