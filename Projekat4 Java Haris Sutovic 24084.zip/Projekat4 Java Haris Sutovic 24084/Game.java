package Projekat;

import java.util.*;


class Game {
private Player player;
private ArrayList<Enemy> enemies = new ArrayList<>();
private ArrayList<String> log = new ArrayList<>();


public Game(Player p) { player = p; }


public void addEnemy(Enemy e) {
if (e == null) throw new IllegalArgumentException();
enemies.add(e);

     }


public boolean checkCollision(GameObject a, GameObject b) { return a.intersects(b); }


public void decreaseHealth(Player p, Enemy e) {
int h = p.getHealth() - e.getEffectiveDamage();
if (h < 0) h = 0;
p.setHealth(h);
log.add("HIT: " + e.getDisplayName() + " -> Player HP=" + h);


      }


public ArrayList<Enemy> collidingWithPlayer() {
ArrayList<Enemy> out = new ArrayList<>();
for (Enemy e : enemies) if (checkCollision(player, e)) out.add(e);
return out;
 
 
      }


public void resolveCollisions() {
for (Enemy e : enemies) if (checkCollision(player, e)) decreaseHealth(player, e);
    
        }


public static Enemy parseEnemy(String s) {
try {
String[] p = s.split(";");
String type = p[0];
double x = Double.parseDouble(p[1]);
double y = Double.parseDouble(p[2]);
String[] size = p[3].split("x");
double a = Double.parseDouble(size[0]);
double b = Double.parseDouble(size[1]);
String kind = p[4];


Collidable c;
if (a == b) c = new CircleCollider(a / 2);
else c = new RectangleCollider(a, b);


if (kind.equals("boss")) return new BossEnemy(type, x, y, c, 25, 100);
return new MeleeEnemy(type, x, y, c, 10, 50);
} catch (Exception e) {
throw new IllegalArgumentException();
    

        }
}


public ArrayList<String> getLog() { return log; 

        }
  }