package Projekat;

interface Collidable {
	
boolean intersects(Collidable other);

void setPosition(double x, double y);

}