package Projekat;

public interface Collidablee {

}
